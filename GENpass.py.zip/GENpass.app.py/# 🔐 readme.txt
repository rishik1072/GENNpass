# 🔐 Secure Password Generator (Python GUI)

A desktop-based password generator application built using **Python and Tkinter**.  
This tool helps users generate strong, secure, and customizable passwords through an easy-to-use graphical interface.

---

## 📌 Features

- Generate strong random passwords
- Custom password length (minimum length enforced)
- Option to include:
  - Uppercase letters (A–Z)
  - Lowercase letters (a–z)
  - Digits (0–9)
  - Special characters (!@#$%^&*)
- Input validation and error handling
- One-click **copy to clipboard** feature
- Simple and user-friendly GUI

---

## 🖥️ User Interface

The application provides a clean graphical interface where users can:
1. Enter the desired password length  
2. Select character types using checkboxes  
3. Generate a secure password  
4. Copy the generated password directly to the clipboard  

---

## 🛠️ Technologies Used

- **Python**
- **Tkinter** (GUI framework)
- **random** module
- **string** module

---

## 📂 Project Structure

secure-password-generator/
│
├── password_app.py
└── README.md

yaml
Copy code

---

## ⚙️ Installation & Setup

### 🔹 Prerequisites
- Python **3.8 or higher**
- Windows / Linux / macOS

> Tkinter comes pre-installed with standard Python distributions.

---

### 🔹 Step 1: Clone the Repository
```bash
git clone https://github.com/your-username/secure-password-generator.git
🔹 Step 2: Navigate to Project Directory
bash
Copy code
cd secure-password-generator
🔹 Step 3: Verify Python Installation
bash
Copy code
python --version
or

bash
Copy code
py --version
🔹 Step 4: Run the Application
bash
Copy code
python password_app.py
The graphical password generator window will open.

🔒 Security Considerations
Enforces a minimum password length

Prevents generation without selecting character types

Uses randomized character selection for stronger passwords

📄 Use Case
This project is useful for:

Learning Python GUI development

Understanding password security basics

Generating strong passwords for personal or academic use

Demonstrating Python and Tkinter skills in resumes or portfolios

📌 Resume Description
Secure Password Generator | Python, Tkinter
Developed a GUI-based desktop application to generate secure passwords with customizable rules, input validation, and clipboard integration.

🚀 Future Enhancements
Password strength meter

Dark mode UI

Secure password storage (encrypted)

Export passwords to a file

👤 Author
Gorakala Rishik

GitHub: https://github.com/rishik1072

LinkedIn: https://www.linkedin.com/in/rishik-gorakala-4b6b78289/

📜 License
This project is created for educational purposes and is free to use.


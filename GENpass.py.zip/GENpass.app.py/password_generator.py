import random
import string
import tkinter as tk
from tkinter import messagebox


def generate_password():
    try:
        length = int(length_entry.get())

        if length < 6:
            messagebox.showerror("Error", "Password length must be at least 6")
            return

        characters = ""
        if var_upper.get():
            characters += string.ascii_uppercase
        if var_lower.get():
            characters += string.ascii_lowercase
        if var_digits.get():
            characters += string.digits
        if var_symbols.get():
            characters += string.punctuation

        if not characters:
            messagebox.showerror("Error", "Select at least one option")
            return

        password = "".join(random.choice(characters) for _ in range(length))
        result_entry.delete(0, tk.END)
        result_entry.insert(0, password)

    except ValueError:
        messagebox.showerror("Error", "Please enter a valid number")


def copy_password():
    root.clipboard_clear()
    root.clipboard_append(result_entry.get())
    messagebox.showinfo("Copied", "Password copied to clipboard")


# App Window
root = tk.Tk()
root.title("Secure Password Generator")
root.geometry("420x380")
root.resizable(False, False)

# UI Layout
tk.Label(root, text="Password Length").pack(pady=5)
length_entry = tk.Entry(root)
length_entry.pack()

var_upper = tk.BooleanVar(value=True)
var_lower = tk.BooleanVar(value=True)
var_digits = tk.BooleanVar(value=True)
var_symbols = tk.BooleanVar(value=False)

tk.Checkbutton(root, text="Include Uppercase Letters", variable=var_upper).pack(
    anchor="w", padx=40
)
tk.Checkbutton(root, text="Include Lowercase Letters", variable=var_lower).pack(
    anchor="w", padx=40
)
tk.Checkbutton(root, text="Include Digits", variable=var_digits).pack(
    anchor="w", padx=40
)
tk.Checkbutton(root, text="Include Symbols", variable=var_symbols).pack(
    anchor="w", padx=40
)

tk.Button(root, text="Generate Password", command=generate_password).pack(pady=15)

result_entry = tk.Entry(root, width=40)
result_entry.pack(pady=10)

tk.Button(root, text="Copy to Clipboard", command=copy_password).pack()

root.mainloop()
